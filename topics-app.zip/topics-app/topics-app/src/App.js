import {
    AppBar,
    Card,
    CardContent,
    CardHeader,
    Container,
    makeStyles,
    Toolbar,
    Typography,
} from '@material-ui/core';
import { grey } from '@material-ui/core/colors';

import TopicSection from './components/topic/TopicSection';

const useStyles = makeStyles((theme) => ({
    appData: {
        maxWidth: 1200,
        padding: theme.spacing(2),
    },
    main: {
        background: theme.palette.background.paper,
        minHeight: '100vh'
    },
    appBar: {
        background: grey[900],
    },
    card: {
        background: theme.palette.background.default
    }
}));


function App() {
    const classes = useStyles();
    return (
        <main className={classes.main}>
            <AppBar className={classes.appBar}>
                <Toolbar>
                    <Typography variant="h5">
                        Github Topics Search App
                    </Typography>
                </Toolbar>
            </AppBar>
            <Toolbar />
            <Container className={classes.appData}>
                <Card className={classes.card}>
                    <CardHeader title="Search Topic" />
                    <CardContent>
                        <TopicSection />
                    </CardContent>
                </Card>
            </Container>
        </main>
    );
}

export default App;
