import { MockedProvider } from '@apollo/client/testing';
import {
    render,
    screen,
    cleanup,
    fireEvent,
    waitFor,
    act,
} from '@testing-library/react';
import { GET_TOPICS } from '../../api/hooks/useTopics';
import TopicSection from '../../components/topic/TopicSection';


const mocks = [
    {
        request: {
            query: GET_TOPICS,
            variables: {
                topicNameFilter: 'topic=react',
            },
        },
        result: {
            data: {
                search: {
                    nodes: [
                        {
                            repositoryTopics: {
                                nodes: [
                                    {
                                        topic: {
                                            name: 'react',
                                            stargazerCount: 111,
                                            relatedTopics: [
                                                {
                                                    name: 'vue',
                                                    stargazerCount: 222,
                                                },
                                                {
                                                    name: 'svelte',
                                                    stargazerCount: 333,
                                                },
                                            ],
                                        },
                                    },
                                    {
                                        topic: {
                                            name: 'redux',
                                            stargazerCount: 444,
                                            relatedTopics: [
                                                {
                                                    name: 'thunk',
                                                    stargazerCount: 555,
                                                },
                                                {
                                                    name: 'saga',
                                                    stargazerCount: 345,
                                                },
                                            ],
                                        },
                                    },
                                ],
                            },
                            __typename: 'Repository',
                        },
                    ],
                },
            },
        },
    },
];

const mocksWithoutTopics = [
    {
        request: {
            query: GET_TOPICS,
            variables: {
                topicNameFilter: 'topic=react-redux',
            },
        },
        result: {
            data: {
                search: {
                    nodes: [],
                },
            },
        },
    },
];

describe('TopicsContainer', () => {
    afterEach(cleanup);

    it('should render topics list', async () => {
        await act(async () => {
            const { getByText, getByTestId } = render(
                <MockedProvider mocks={mocks} addTypename={true}>
                    <TopicSection />
                </MockedProvider>
            );

            const input = getByTestId('topicInput').querySelector('input');
            fireEvent.change(input, { target: { value: 'react' } });

            await waitFor(() => screen.getAllByTestId('topicsList'));

            const reduxTopic = getByText('redux');

            expect(reduxTopic).toBeInTheDocument();
        });
    });

    it('should display message when no topics are found', async () => {
        await act(async () => {
            const { getByText, getByTestId } = render(
                <MockedProvider mocks={mocksWithoutTopics} addTypename={true}>
                    <TopicSection />
                </MockedProvider>
            );

            const input = getByTestId('topicInput').querySelector('input');
            fireEvent.change(input, { target: { value: 'react-redux' } });
            await waitFor(() => screen.getAllByTestId('topicsList'));

            const noTopicsText = getByText('No topics found.');
            expect(noTopicsText).toBeInTheDocument();
        });
    });

    test('should open dialog with related topics on clicking topic', async () => {
        const { getByText, getByTestId } = render(
            <MockedProvider mocks={mocks} addTypename={true}>
                <TopicSection />
            </MockedProvider>
        );
        const input = getByTestId('topicInput').querySelector('input');
        fireEvent.change(input, { target: { value: 'react' } });
        await waitFor(() => screen.getAllByTestId('topicsList'));
        const topicListItem = getByText('react');
        fireEvent.click(topicListItem);
        const relatedTopicItem = getByText('svelte');
        expect(relatedTopicItem).toBeInTheDocument();
    });

    it('should close dialog when clicked on close button', async () => {
        const { getByText, getByTestId } = render(
            <MockedProvider mocks={mocks} addTypename={true}>
                <TopicSection />
            </MockedProvider>
        );
        const input = getByTestId('topicInput').querySelector('input');
        fireEvent.change(input, { target: { value: 'react' } });
        await waitFor(() => screen.getAllByTestId('topicsList'));
        const topicListItem = getByText('react');
        fireEvent.click(topicListItem);
        const relatedTopicItem = getByText('svelte');
        expect(relatedTopicItem).toBeInTheDocument();
        fireEvent.click(screen.getByTestId('close-button'))
        expect(relatedTopicItem).not.toBeInTheDocument()
    })
});
