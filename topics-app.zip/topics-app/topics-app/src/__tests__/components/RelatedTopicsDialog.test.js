import { render, screen, cleanup, fireEvent } from '@testing-library/react';
import RelatedTopicsDialog from '../../components/topic/RelatedTopicsDialog';


describe('RelatedTopicsDialog', () => {
    afterEach(cleanup);

    it('should render related topics', () => {
        render(
            <RelatedTopicsDialog
                open={true}
                relatedTopics={[
                    {
                        name: 'django',
                        stargazerCount: 11,
                    },
                    {
                        name: 'react',
                        stargazerCount: 123,
                    },
                ]}
                onClose={() => {}}
            />
        );
        const topic1 = screen.getByText(/django/i);
        const topic2 = screen.getByText(/react/i);
        expect(topic1).toBeInTheDocument();
        expect(topic2).toBeInTheDocument();
    });

    it('should render correctly when related topics are 0', () => {
        render(
            <RelatedTopicsDialog
                open={true}
                relatedTopics={[]}
                onClose={() => {}}
            />
        );
        const noTopics = screen.getByText('No topics found.');
        expect(noTopics).toBeInTheDocument();
    })

    it('should call onClose when clinking on close button', () => {
        const onCloseSpy = jest.fn()
        render(
            <RelatedTopicsDialog
                open
                relatedTopics={[]}
                onClose={onCloseSpy}
            />
        )
        fireEvent.click(screen.getByTestId('close-button'))
        expect(onCloseSpy).toBeCalledTimes(1)
    })
});
