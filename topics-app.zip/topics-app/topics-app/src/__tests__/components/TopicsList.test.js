
import {
    render,
    cleanup,
    fireEvent,
} from '@testing-library/react';
import TopicsList from '../../components/topic/TopicsList';


const topics = [
    {
        topic: {
            name: 'react',
            stargazerCount: 123,
            relatedTopics: [
                {
                    name: 'react1',
                    stargazerCount: 156,
                },
                {
                    name: 'react2',
                    stargazerCount: 184,
                },
            ],
        },
    },
]

const relatedTopics = [{
    name: 'related-react',
    stargazerCount: 123,
}]

describe('TopicsList', () => {
    afterEach(cleanup);

    const onTopicSelectSpy = jest.fn();
    
    it('should render trigger onTopicSelect handler on item click', () => {
        const { getByRole } = render(
            <TopicsList
                topics={topics}
                onTopicSelect={onTopicSelectSpy}
            />
        );
        const clickableElement = getByRole('button');
        fireEvent.click(clickableElement);
        expect(onTopicSelectSpy).toBeCalled();
    });
    
    it('should render topics list correctly when isRelatedTopics is true', async () => {
        const { getByText } = render(
            <TopicsList topics={relatedTopics} isRelatedTopics />
        );
        const reactTopic = getByText('related-react');
        expect(reactTopic).toBeInTheDocument();
    });

    it('should render topics list correctly when isRelatedTopics is false', async () => {
        const { getByText } = render(
            <TopicsList topics={topics} />
        );
        const reactTopic = getByText('react');
        expect(reactTopic).toBeInTheDocument();
    });

    it('should display error message when error', () => {
        const { getByText } = render(
            <TopicsList topics={relatedTopics} isRelatedTopics error="Something went wrong! :(" />
        );
        const error = getByText("Error! Something went wrong! :(");
        expect(error).toBeInTheDocument();
    })
})


