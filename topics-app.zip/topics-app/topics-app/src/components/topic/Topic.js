import { Chip, ListItem, ListItemText, makeStyles } from '@material-ui/core';
import { grey, yellow } from '@material-ui/core/colors';
import { Star } from '@material-ui/icons';
import PropTypes from 'prop-types';

const useStyles = makeStyles({
    topicText: {
        color: grey[50]
    },
    chip: {
        background: grey[900]
    },
    star: {
        color: yellow[600]
    }
})

const Topic = ({ topic, onClick }) => {
    const classes = useStyles()
    return (
        <ListItem button divider onClick={onClick}>
            <ListItemText data-testid="topicName" primary={topic?.name} className={classes.topicText} />
            <Chip 
                icon={<Star className={classes.star} fontSize="small" />}
                className={classes.chip}
                color="secondary"
                label={topic?.stargazerCount}
            />
        </ListItem>
    )
}

Topic.propTypes = {
    topic: PropTypes.shape({
        name: PropTypes.string,
        stargazerCount: PropTypes.number,
        relatedTopics: PropTypes.arrayOf(
            PropTypes.shape({
                name: PropTypes.string,
                stargazerCount: PropTypes.number,
            })
        ),
    }).isRequired,
    onClick: PropTypes.func,
};

export default Topic;
