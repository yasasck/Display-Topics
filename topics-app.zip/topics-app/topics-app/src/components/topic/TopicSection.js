import { useState } from 'react';
import TopicsList from './TopicsList';
import { Grid } from '@material-ui/core';
import useTopics from '../../api/hooks/useTopics';
import RelatedTopicsDialog from './RelatedTopicsDialog';
import SearchInput from './SearchInput'

const TopicSection = () => {
    const [topicText, setTopicText] = useState('react')
    const { loading, error, topics } = useTopics(topicText)

    const handleChange = ({ target: { value } }) => setTopicText(value)

    const [selectedTopic, setSelectedTopic] = useState(null)
    const onTopicSelect = topic => setSelectedTopic(topic)
    const onClose = () => setSelectedTopic(null)

    return (<>
        <RelatedTopicsDialog open={!!selectedTopic} relatedTopics={selectedTopic?.relatedTopics} onClose={onClose} />
        <Grid container>
            <Grid item xs={12}>
                <SearchInput value={topicText} onChange={handleChange} />
                <TopicsList topics={topics} onTopicSelect={onTopicSelect} loading={loading} error={error} />
            </Grid>
        </Grid>
    </>);
};

export default TopicSection;
