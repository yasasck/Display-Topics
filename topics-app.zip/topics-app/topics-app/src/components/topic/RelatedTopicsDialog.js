import { Dialog, DialogTitle, Grid, IconButton, makeStyles, Typography } from '@material-ui/core';
import { Close } from '@material-ui/icons';
import TopicsList from './TopicsList';

const useStyles = makeStyles({
    titleSection: {
        display: 'flex',
        justifyContent: 'space-between'
    }
})

const RelatedTopicsDialog = ({ open, relatedTopics, onClose }) => {
    const classes = useStyles();
    return <Dialog fullWidth open={open} onClose={onClose}>
        <DialogTitle disableTypography className={classes.titleSection}>
            <Typography variant="h4">Related Topics</Typography>
            <IconButton onClick={onClose} data-testid="close-button"><Close /></IconButton>
        </DialogTitle>
        <Grid container>
            <Grid item xs={12}>
                <TopicsList topics={relatedTopics} isRelatedTopics />
            </Grid>
        </Grid>
    </Dialog>
}


export default RelatedTopicsDialog;
