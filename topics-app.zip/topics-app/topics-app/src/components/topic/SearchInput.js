import { TextField } from "@material-ui/core";
import PropTypes from "prop-types";
import { SearchOutlined } from '@material-ui/icons';

const SearchInput = ({ value, onChange }) => <TextField
    fullWidth
    placeholder="Search topic"
    data-testid="topicInput"
    variant="outlined"
    name="topicText"
    value={value}
    onChange={onChange}
    InputProps={{
        endAdornment: <SearchOutlined />
    }}
/>

SearchInput.propTypes = {
    value: PropTypes.string,
    onChange: PropTypes.func
}

export default SearchInput